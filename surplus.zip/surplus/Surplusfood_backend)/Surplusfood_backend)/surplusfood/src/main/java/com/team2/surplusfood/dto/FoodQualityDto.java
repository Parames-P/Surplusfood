package com.team2.surplusfood.dto;

import lombok.Data;

@Data
public class FoodQualityDto {
    private String quality;
}
